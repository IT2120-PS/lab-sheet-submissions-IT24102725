#Exercise

#part 1
#Import the dataset
data<-read.csv("Exercise.csv")
fix(data)
#Loading to data frame called “student data”
student_data <- read.csv("Exercise.csv")
fix(student_data)

#part 2
#Summary statistics
summary(student_data)
#histogram for the variable “X1” (Age)
dev.new(width=10, height=6)  # Opens a new window (in inches)
hist(student_data$X1)

#part 3
#one-way frequency table
gender.freq <- table(student_data$X2)
gender.freq
#bar chart
dev.new(width=10, height=6)  # Opens a new window (in inches)
barplot(gender.freq, main="Bar Chart", ylab = "Frequency", xlab = "Gender")
abline(h=0)

#Part 4
#Side-by-side boxplots
dev.new(width=10, height=6)  # Opens a new window (in inches)
boxplot(student_data$X1~student_data$X3, main = "Boxplot for Age and Accommodation", xlab = "Accommodation", ylab = "Age")








